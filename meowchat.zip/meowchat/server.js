const WebSocket = require('ws');
const express = require('express');
const path = require('path');
const crypto = require('crypto');

const app = express();
const server = require('http').createServer(app);
const wss = new WebSocket.Server({ server });

// Хранилище в памяти
const users = new Map();
const rooms = new Map();

// Стартовые комнаты
rooms.set('general', {
  id: 'general',
  name: '🐱 Общая комната',
  theme: '#7c3aed',
  description: 'Главный чат для всех котиков',
  messages: [],
  users: new Set()
});

rooms.set('memes', {
  id: 'memes',
  name: '😹 Котики и мемы',
  theme: '#f59e0b',
  description: 'Делимся смешными картинками',
  messages: [],
  users: new Set()
});

rooms.set('gaming', {
  id: 'gaming',
  name: '🎮 Игровая',
  theme: '#10b981',
  description: 'Обсуждаем игры',
  messages: [],
  users: new Set()
});

function broadcastRooms() {
  const roomsList = Array.from(rooms.values()).map(r => ({
    id: r.id,
    name: r.name,
    theme: r.theme,
    description: r.description,
    userCount: r.users.size
  }));
  for (const [, user] of users) {
    if (user.ws.readyState === WebSocket.OPEN) {
      user.ws.send(JSON.stringify({ type: 'rooms_list', payload: { rooms: roomsList } }));
    }
  }
}

function broadcastOnlineUsers() {
  const onlineUsers = Array.from(users.values()).map(u => ({
    id: u.id,
    name: u.name,
    avatar: u.avatar,
    color: u.color
  }));
  for (const [, user] of users) {
    if (user.ws.readyState === WebSocket.OPEN) {
      user.ws.send(JSON.stringify({ type: 'online_users', payload: { users: onlineUsers } }));
    }
  }
}

function sendToRoom(roomId, data) {
  const room = rooms.get(roomId);
  if (!room) return;
  for (const uid of room.users) {
    const u = users.get(uid);
    if (u && u.ws.readyState === WebSocket.OPEN) {
      u.ws.send(JSON.stringify(data));
    }
  }
}

wss.on('connection', (ws) => {
  let userId = null;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    switch (msg.type) {

      case 'login': {
        userId = crypto.randomUUID();
        const user = {
          id: userId,
          name: msg.payload.name || 'Анонимный кот',
          avatar: msg.payload.avatar || '🐱',
          color: msg.payload.color || '#7c3aed',
          ws: ws
        };
        users.set(userId, user);
        ws.send(JSON.stringify({
          type: 'login_success',
          payload: { id: user.id, name: user.name, avatar: user.avatar, color: user.color }
        }));
        broadcastRooms();
        broadcastOnlineUsers();
        break;
      }

      case 'get_rooms': {
        const roomsList = Array.from(rooms.values()).map(r => ({
          id: r.id, name: r.name, theme: r.theme,
          description: r.description, userCount: r.users.size
        }));
        ws.send(JSON.stringify({ type: 'rooms_list', payload: { rooms: roomsList } }));
        break;
      }

      case 'create_room': {
        const roomId = crypto.randomUUID();
        rooms.set(roomId, {
          id: roomId,
          name: msg.payload.name || 'Новый чат',
          theme: msg.payload.theme || '#7c3aed',
          description: msg.payload.description || '',
          messages: [],
          users: new Set()
        });
        broadcastRooms();
        ws.send(JSON.stringify({ type: 'room_created', payload: { roomId } }));
        break;
      }

      case 'join_room': {
        const room = rooms.get(msg.payload.roomId);
        if (!room) return;
        // Покидаем все предыдущие комнаты
        for (const [, r] of rooms) r.users.delete(userId);
        room.users.add(userId);
        const msgs = room.messages.slice(-100);
        ws.send(JSON.stringify({
          type: 'room_joined',
          payload: { roomId: room.id, name: room.name, theme: room.theme, messages: msgs }
        }));
        broadcastOnlineUsers();
        broadcastRooms();
        break;
      }

      case 'send_message': {
        const room = rooms.get(msg.payload.roomId);
        if (!room) return;
        const user = users.get(userId);
        if (!user) return;
        const message = {
          id: crypto.randomUUID(),
          userId: userId,
          userName: user.name,
          userAvatar: user.avatar,
          userColor: user.color,
          text: msg.payload.text,
          timestamp: Date.now()
        };
        room.messages.push(message);
        if (room.messages.length > 500) room.messages = room.messages.slice(-500);
        sendToRoom(room.id, { type: 'new_message', payload: message });
        break;
      }

      case 'update_profile': {
        const user = users.get(userId);
        if (!user) return;
        if (msg.payload.name) user.name = msg.payload.name;
        if (msg.payload.avatar) user.avatar = msg.payload.avatar;
        if (msg.payload.color) user.color = msg.payload.color;
        broadcastOnlineUsers();
        ws.send(JSON.stringify({
          type: 'profile_updated',
          payload: { id: user.id, name: user.name, avatar: user.avatar, color: user.color }
        }));
        break;
      }

      case 'update_room': {
        const room = rooms.get(msg.payload.roomId);
        if (!room) return;
        if (msg.payload.name) room.name = msg.payload.name;
        if (msg.payload.theme) room.theme = msg.payload.theme;
        if (msg.payload.description !== undefined) room.description = msg.payload.description;
        broadcastRooms();
        sendToRoom(room.id, {
          type: 'room_updated',
          payload: { roomId: room.id, name: room.name, theme: room.theme, description: room.description }
        });
        break;
      }

      case 'delete_room': {
        rooms.delete(msg.payload.roomId);
        broadcastRooms();
        break;
      }
    }
  });

  ws.on('close', () => {
    if (userId) {
      for (const [, room] of rooms) room.users.delete(userId);
      users.delete(userId);
      broadcastOnlineUsers();
      broadcastRooms();
    }
  });
});

app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🐱 MeowChat сервер запущен на http://localhost:${PORT}`);
  console.log(`   Открой этот адрес в браузере, чтобы войти в чат!`);
});
